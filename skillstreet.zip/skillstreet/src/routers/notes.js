const express = require('express')
const router = express.Router()

const auth = require('../middleware/auth')

const Note = require('../models/notes')

router.post('/user/createNote' , auth , async(req,res)=>{
    const note = new Note({
        ...req.body,
        owner : req.user._id,
    })
    try{
        await note.save()
        res.status(201).send(note) 
    } catch (e) {
        res.status(400).send(e)
    }
})

router.get('/user/getNotes' , auth , async(req,res)=>{
    try{
    const notes = await Note.find({owner:req.user._id})
    console.log(notes)
    res.status(200).send(
        notes
    )
    } catch (e) {
        res.status(500).send(e)
    }
})

router.get('/user/getNote/:id' , auth ,async(req,res)=> {
    const _id = req.params.id
    try{
        const note = await Note.findOne({_id , owner : req.user._id})
        if(!note) throw new Error('Invalid')
        res.status(200).send(note)

    } catch (e) {
        res.status(402).send(e)
    }
})
router.patch('/user/updateNote/:id', auth, async (req, res) => {
    const updates = Object.keys(req.body);
    const allowedUpdates = [ 'description','content'];

    const isValidOperation = updates.every((update) => allowedUpdates.includes(update));

    if (!isValidOperation) {
        return res.status(400).send({ error: 'Invalid update' });
    }

    try {
        const note = await Note.findOne({
            _id: req.params.id,
            owner: req.user._id,
        });

        if (!note) {
            return res.status(404).send({ error: 'Note not found' });
        }

        updates.forEach((update) => (note[update] = req.body[update]));

        await note.save();
        res.status(200).send(note);
    } catch (e) {
        res.status(500).send({ error: e.message });
    }
});


router.delete('/user/deleteNote/:id', auth , async (req,res)=>{
    try{
        const note = await Note.findOneAndDelete({
            _id : req.params.id , 
            owner : req.user._id
        })
        if(!note) throw new Error('Note to be deleted not found')
        res.status(204).send(note) 

    } catch (e) {
        return res.status(502).send(e)
    }
})



module.exports = router