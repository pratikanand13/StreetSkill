const mongoose = require('mongoose')
const validator = require('validator')

const noteSchema = new mongoose.Schema({
    description : {
        type : String,
        required : true,
        trim : true
     },
    content : {
        type : String,
        required : false,

     },
    owner: {
        type : mongoose.Schema.Types.ObjectId,  
        required : true , 
        ref : 'User'
    },
},{
    timestamps : true
})
const Note = mongoose.model('notes' , noteSchema)
module.exports = Note