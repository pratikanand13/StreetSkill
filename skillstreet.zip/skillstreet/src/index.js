const express = require('express')
const app = express()
require("./db/mongoose");
const port = process.env.PORT || 3000
const jwt = require('jsonwebtoken')

const User = require('./models/users')
const Note = require('./models/notes')

const noteRouter = require('./routers/notes')
const userRouter = require('./routers/users')

app.use(express.json())
app.use(noteRouter)
app.use(userRouter)






app.listen(port, () => {
    console.log(`Server is running on ${port}`);
  });
  